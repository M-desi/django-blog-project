from django.shortcuts import render
from .models import post

posts = [
    {
        'author': 'CoreyMs',
        'title': 'Blog post',
        'content': 'first post content',
        'date_posted': 'August 27, 2020'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog post',
        'content': 'Second post content',
        'date_posted': 'August 28, 2020'
    }
]

def home(request):
    context = {
        'posts': post.objects.all()
    }
    return render(request, 'blog/home.html', context)


def about(request):
    return render(request, 'blog/about.html', {'title': 'About'})
